var score = 0;
var scoreShows = 0;
var scoreWw = 0;
var scoreCartoons = 0;
var scorePp = 0;
var scoreFf = 0;



var  aa = [
	{
		'question': "wew",
		'choices': ["wew", "aw", "as"],
		'correctChoice': "wew",
		flag: 0
	},
	{
		'question': "aw",
		'choices': ["asd", "Delaware", "aw"],
		'correctChoice': "aw",
		flag: 0
	},
	{
		'question': "asdas",
		'choices': ["asdas","aw","wew"],
		'correctChoice': "asdas",
		flag: 0
	},
	{
		'question': "qw",
		'choices': ["qw", "sad", "ads"],
		'correctChoice': "qw",
		flag: 0
	},

	{
		'question': "sad",
		'choices': ["aaf", "sad", "adg"],
		'correctChoice': "sad",
		flag: 0
	},
	{
		'question': "ser",
		'choices': ["sad", "fs", "ser"],
		'correctChoice': "ser",
		flag: 0
	},
	{
		'question': "dsad",
		'choices': ["dsad", "asf", "asda", "adv"],
		'correctChoice': "dsad",
		flag: 0
	},

	{
		'question': "dsa",
		'choices': ["affa", "dsa", "adsf"],
		'correctChoice': "dsa",
		flag: 0
	},

	{
		'question': "as",
		'choices': ["as", "dasc", "zxc"],
		'correctChoice': "as",
		flag: 0
	},
	{
		'question': "amid",
		'choices': ["asdaf", "xzc", "gds"],
		'correctChoice': "asdaf",
		flag: 0
	},
	{
		'question': "hard",
		'choices': ["asdaf", "hard", "gds"],
		'correctChoice': "hard",
		flag: 0
	},
	{
		'question': "aslow",
		'choices': ["asdaf", "heasy", "gds"],
		'correctChoice': "heasy",
		flag: 0
	},
	
]


var  ww = [
	{
		'question': "qaa",
		'choices': ["qposls", "wsssa", "sssse"],
		'correctChoice': "sssse",
		flag: 0
	},
	{
		'question': "qssa",
		'choices': ["qass", "wsa", "ase"],
		'correctChoice': "qass",
		flag: 0
	},
	{
		'question': "x",
		'choices': ["x","asaw","easa"],
		'correctChoice': "x",
		flag: 0
	},
	{
		'question': "qsd",
		'choices': ["qsd", "wfd", "dddae"],
		'correctChoice': "qsd",
		flag: 0
	},

	{
		'question': "qasas",
		'choices': ["qasas", "wwqqw", "sse"],
		'correctChoice': "qasas",
		flag: 0
	},
	{
		'question': "wqweq",
		'choices': ["wqweq", "dfgw", "sdse"],
		'correctChoice': "wqweq",
		flag: 0
	},
	{
		'question': "q",
		'choices': ["q", "wwwq", "qqwe"],
		'correctChoice': "qesa",
		flag: 0
	},

	{
		'question': "qwed",
		'choices': ["qwed", "w", "e"],
		'correctChoice': "qwed",
		flag: 0
	},

	{
		'question': "q",
		'choices': ["q", "w", "e"],
		'correctChoice': "q",
		flag: 0
	},
	{
		'question': "qa",
		'choices': ["qa", "w", "e"],
		'correctChoice': "qa",
		flag: 0
	},
	
]

var  pp = [
	{
		'question': "qo",
		'choices': ["qo", "w", "e"],
		'correctChoice': "qo",
		flag: 0
	},
	{
		'question': "aq",
		'choices': ["q", "aw", "e"],
		'correctChoice': "aw",
		flag: 0
	},
	{
		'question': "q",
		'choices': ["aq","aw","e"],
		'correctChoice': "aq",
		flag: 0
	},
	{
		'question': "qeaa",
		'choices': ["qeaa", "w", "e"],
		'correctChoice': "qeaa",
		flag: 0
	},

	{
		'question': "sq",
		'choices': ["sq", "w", "e"],
		'correctChoice': "sq",
		flag: 0
	},
	{
		'question': "qass",
		'choices': ["qass", "w", "e"],
		'correctChoice': "qass",
		flag: 0
	},
	{
		'question': "q",
		'choices': ["q", "wass", "e"],
		'correctChoice': "wass",
		flag: 0
	},

	{
		'question': "q",
		'choices': ["qcxx", "w", "e"],
		'correctChoice': "qcxx",
		flag: 0
	},

	{
		'question': "q",
		'choices': ["q", "w", "e"],
		'correctChoice': "q",
		flag: 0
	},
	{
		'question': "q",
		'choices': ["qa", "w", "e"],
		'correctChoice': "qa",
		flag: 0
	},
	
]
// antonyms men!!!!

var  shows = [
	{
		'question': "On 'Friends', what was Rachel's error on her resume in the episode with all the poker?",
		'choices': ["She spelled 'computer' wrong", "Spelled her name wrong", "Forgot to include contact information"],
		'correctChoice': "She spelled 'computer' wrong",
		flag: 0
	},
	{
		'question': "On boy meets world, what is the crazy older brother's name?",
		'choices': ["Henry", "Patrick", "James", "Eric", "Daniel"],
		'correctChoice': "Henry",
		flag: 0
	},
	{
		'question': "Who was DJ's best friend's name on 'Full House'",
		'choices': ["Jessica","Kylie","Stephanie", "Kimmy"],
		'correctChoice': "Kimmy",
		flag: 0
	},
	{
		'question': "In 'Saved by the Bell', what were Zack and Kelly dressed up as the night they broke up?",
		'choices': ["monkeys", "Romeo and Juliet", "clowns", "Adam and Eve"],
		'correctChoice': "Romeo and Juliet",
		flag: 0
	},

	{
		'question': "In Growing Pains, What was boners dad's name?",
		'choices': ["Jefferson", "Robert", "Sylvester", "Edward"],
		'correctChoice': "Sylvester",
		flag: 0
	},
	{
		'question': "On an episode of 'Friends', what did Jean-Claude Van Damme boast he could do?",
		'choices': ["crush a walnut with his butt", "take cap off bottle with his eye", "touch his nose with his tongue"],
		'correctChoice': "crush a walnut with his butt",
		flag: 0
	},
	{
		'question': "In Fresh Prince of Bel-Air what was the butlers name?",
		'choices': ["Phil", "Geoffrey", "Grant", "George"],
		'correctChoice': "Geoffrey",
		flag: 0
	},

	{
		'question': "How did Danny Tanner's wife die on 'Full House'?",
		'choices': ["cancer", "car crash", "drug overdose", "unknown circumstances"],
		'correctChoice': "car crash",
		flag: 0
	},

	{
		'question': "Which of the following was Chandler's girlfriend at some point in 'Friends'?",
		'choices': ["Jannette", "Julia", "Janice", "Jasmine"],
		'correctChoice': "Janice",
		flag: 0
	},
	{
		'question': "On Saved By The Bell, what was the name of the beach club that the gang worked at?",
		'choices': ["Malibu Sands Beach Club", "Venice Beach club", "Aloha Beach Club", "none of the above"],
		'correctChoice': "Malibu Sands Beach Club",
		flag: 0
	},
	
]
var  cartoons = [
	{
		'question': "Who did Arnold live with on 'Hey Arnold'?",
		'choices': ["parents", "aunt and uncle", "grandparents"],
		'correctChoice': "grandparents",
		flag: 0
	},
	{
		'question': "How did Tommy's family know Angelica's family in 'Rugrats'?",
		'choices': ["neighbors", "family friends", "relatives"],
		'correctChoice': "relatives",
		flag: 0
	},
	{
		'question': "True or False: In 'Rocko's Modern Life', Rocko was a Kangaroo.",
		'choices': ["True","False"],
		'correctChoice': "False",
		flag: 0
	},
	{
		'question': "What was the name of Arnold's best friend in 'Hey Arnold'?",
		'choices': ["Eugene", "Alfred", "Gerald", "Doug"],
		'correctChoice': "Gerald",
		flag: 0
	},

	{
		'question': "What is the name of Dexter's annoying sister in 'Dexter's Laboratory'?",
		'choices': ["Jesse", "Deedee", "Meemee", "Lili"],
		'correctChoice': "Deedee",
		flag: 0
	},
	{
		'question': "In 'Doug', what was the name of Doug's dog?",
		'choices': ["Porkchop", "Peppers", "Max"],
		'correctChoice': "Porkchop",
		flag: 0
	},
	{
		'question': "In 'Courage The Cowardly Dog', what was the setting of the show?",
		'choices': ["Middle of Nowhere", "city", "small town", "Suburbs"],
		'correctChoice': "Middle of Nowhere",
		flag: 0
	},

	{
		'question': "What is the name of Tommy's little brother in 'Rugrats'?",
		'choices': ["Patric", "Chucky", "Phil", "Dil"],
		'correctChoice': "Dil",
		flag: 0
	},

	{
		'question': "What was the name of Arnold's secret admirer in 'Hey Arnold'?",
		'choices': ["Helga", "Julia", "Hagen", "Olga"],
		'correctChoice': "Helga",
		flag: 0
	},
	{
		'question': "What is the name CatDog's mouse friend in 'CatDog'?",
		'choices': ["Albert", "Teddy", "Winslow", "Wilbur"],
		'correctChoice': "Winslow",
		flag: 0
	},
]
var  ff = [
	{
		'question': "antonyms",
		'choices': ["q", "show", "e"],
		'correctChoice': "q",
		flag: 0
	},
	{
		'question': "qssa",
		'choices': ["qsss", "w", "e"],
		'correctChoice': "qsss",
		flag: 0
	},
	{
		'question': "qff",
		'choices': ["qFf","w","e"],
		'correctChoice': "qFf",
		flag: 0
	},
	{
		'question': "q",
		'choices': ["qdd", "w", "e"],
		'correctChoice': "qdd",
		flag: 0
	},

	{
		'question': "q",
		'choices': ["qddd", "w", "e"],
		'correctChoice': "qddd",
		flag: 0
	},
	{
		'question': "q",
		'choices': ["q", "w", "e"],
		'correctChoice': "q",
		flag: 0
	},
	{
		'question': "q",
		'choices': ["q", "w", "e"],
		'correctChoice': "q",
		flag: 0
	},

	{
		'question': "q",
		'choices': ["q", "w", "e"],
		'correctChoice': "q",
		flag: 0
	},

	{
		'question': "q",
		'choices': ["q", "w", "e"],
		'correctChoice': "q",
		flag: 0
	},
	{
		'question': "q",
		'choices': ["q", "w", "e"],
		'correctChoice': "q",
		flag: 0
	},
]

function randomize(category){
	var checkAsked = 0;
	for(var i=0; i<category.length; i++)
	{
		if(category[i].flag == 1)
			checkAsked++;
	}

	if(checkAsked == 10)
	{
		return -1;
	}
	else{
		var r = Math.floor(Math.random() * 10);
		while(category[r].flag == 1)
		{
			r = Math.floor(Math.random() * 10);
		}
		category[r].flag = 1;
		return r;
	}
}

function refresh() {
    window.location.replace("#mainPage");
    $(document).on("pagebeforeshow","#mainPage", function() {
        window.location.reload();
    });
}

var count;
function showAa() {

    for(var i=0; i<aa.length; i++)
        aa[i].flag = 0;
    $(document).ready(function showAaQuestions(){
        $('#qa').show();
        count = randomize(aa);
        if (count == -1)
        {
            $('#nextStop').hide();
            $('#result').show();
            $('#score2').html(score);
            $('#playAgain').show();
            $('#return').show();
            $('#playAgain').click(function(){
                $('#return').hide();
                $('#result').hide();
                $('#playAgainAa').hide();
                score=0;
                showAa();
            });
            $('#return').click( function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });
        }
        var whereToAdd = document.getElementById("qa");
        // Check if already an unordered list is present. If so remove it.
        removeExistingQuestion(whereToAdd, "aa_choices");
    
        var q = document.createElement("h4");
        q.setAttribute('id', 'inquiry');
        var txt = document.createTextNode(aa[count].question);
        q.appendChild(txt);
        whereToAdd.appendChild(q);
        $('#score').html(score);
        $('#score2').html(score);
    
        // Firstly, create an unordered list of items
        var ulist = document.createElement("ul");
        ulist.setAttribute('id','aa_choices');
        // Create each choice of fruit
        for (var i = 0; i < aa[count].choices.length; ++i){
            // create a radio button for each choice
            var choice = document.createElement("input");
            choice.className = 'ch';
            choice.setAttribute('type','radio');
            choice.setAttribute('id','id'+i);
            choice.setAttribute('name','aa');
            choice.setAttribute('value',aa[count].choices[i]);
        
            //Add the choice to the UL element
            ulist.appendChild(choice);
        
            // Create a Label
            var aaLabel = document.createElement("label");
            aaLabel.htmlFor = choice.id;
            aaLabel.appendChild(choice);
            var aaNameTextNode = document.createTextNode(aa[count].choices[i]);
            aaLabel.appendChild(aaNameTextNode);
        
            // Add the UL item to the unordered list
            ulist.appendChild(aaLabel);
            // Add a break element
      //      var brElement = document.createElement("br");
    //        ulist.appendChild(brElement);
        }
        //At this point, the entire unordered list of items is created.
        //Add the unordered list to the div.
        whereToAdd.appendChild(ulist);
        $('#nextStop').show();
        $('#next').click(function(){
            
            if ( $("input").is(':checked'))
            {
                var elements = document.getElementsByName('aa');
                for (var i = 0;i < elements.length; i++)
                    {
                        if (elements[i].checked)
                        {
                            if (elements[i].value == aa[count].correctChoice)
                            {
                                score += 5;
                                break;
                            }
                         else
                            break;
                        }
                    }
                showAaQuestions();
            }
           
        });
        $('#stop').click(function(){
            $('#qa').hide();
            $('#nextStop').hide();
            $('#result').show();
            $('#score2').html(score);
            $('#playAgain').show();
            $('#return').show();
            $('#playAgain').click(function(){
                $('#return').hide();
                $('#result').hide();
                $('#playAgainAa').hide();
                score=0;
                showAa();
            });
                         
            $('#return').click(function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });

            });

        });
           
    });
}



function showWw() {
    for(var i=0; i<ww.length; i++)
        ww[i].flag = 0;
    $(document).ready(function showWwQuestions(){
        $('#wwStartPage').hide();
        $('#qaWw').show();
        count = randomize(ww);
        if (count == -1)
        {
            $('#qaWw').hide();
            $('#nextStopWw').hide();
            $('#resultWw').show();
            $('#scoreWw').html(scoreWw);
            $('#playAgainWw').show();
            $('#returnWw').show();
            $('#playAgainWw').click(function(){
                $('#returnWw').hide();
                $('#resultWw').hide();
                $('#playAgainWw').hide();
                scoreWw=0;
                showWw();
            });
            $('#returnWw').click( function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });
        }
        var whereToAdd = document.getElementById("qaWw");
        // Check if already an unordered list is present. If so remove it.
        removeExistingQuestion(whereToAdd, "ww_choices");
    
        var qWw = document.createElement("h4");
        qWw.setAttribute('id', 'inquiry');
        var txt = document.createTextNode(ww[count].question);
        qWw.appendChild(txt);
        whereToAdd.appendChild(qWw);
        $('#scoreWw').html(scoreWw);
    
        // Firstly, create an unordered list of items
        var ulist = document.createElement("ul");
        ulist.setAttribute('id','ww_choices');
        // Create each choice
        for (var i = 0; i < ww[count].choices.length; ++i){
            // create a radio button for each choice
            var choice = document.createElement("input");
            choice.className = 'ch';
            choice.setAttribute('type','radio');
            choice.setAttribute('id','id'+i);
            choice.setAttribute('name','ww');
            choice.setAttribute('value',ww[count].choices[i]);
        
            //Add the choice to the UL element
            ulist.appendChild(choice);
        
            // Create a Label
            var wwLabel = document.createElement("label");
            wwLabel.htmlFor = choice.id;
            wwLabel.appendChild(choice);
            var wwNameTextNode = document.createTextNode(ww[count].choices[i]);
            wwLabel.appendChild(wwNameTextNode);
        
            // Add the UL item to the unordered list
            ulist.appendChild(wwLabel);

        }
        //At this point, the entire unordered list of items is created.
        //Add the unordered list to the div.
        whereToAdd.appendChild(ulist);
        $('#nextStopWw').show();
        $('#nextWw').click(function(){
            
            if ( $("input").is(':checked'))
            {
                var elements = document.getElementsByName('ww');
                for (var i = 0;i < elements.length; i++)
                    {
                        if (elements[i].checked)
                        {
                            if (elements[i].value == ww[count].correctChoice)
                            {
                                scoreWw += 5;
                                break;
                            }
                         else
                            break;
                        }
                    }
                showWwQuestions();
            }
           
        });
        $('#stopWw').click(function(){
            $('#qaWw').hide();
            $('#nextStopWw').hide();
            $('#resultWw').show();
            $('#score2Ww').html(scoreWw);
            $('#playAgainWw').show();
            $('#returnWw').show();
            $('#playAgainWw').click(function(){
                $('#returnWw').hide();
                $('#resultWw').hide();
                $('#playAgainWw').hide();
                scoreWw=0;
                showWw();
            });
            $('#returnWw').click(function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });

        });
           
    });
}




function showPp() {
    for(var i=0; i<pp.length; i++)
        pp[i].flag = 0;
    $(document).ready(function showPpQuestions(){
        $('#ppStartPage').hide();
        $('#qaPp').show();
        count = randomize(pp);
        if (count == -1)
        {
            $('#qaPp').hide();
            $('#nextStopPp').hide();
            $('#resultPp').show();
            $('#scorePp').html(scorePp);
            $('#playAgainPp').show();
            $('#returnPp').show();
            $('#playAgainPp').click(function(){
                $('#returnPp').hide();
                $('#resultPp').hide();
                $('#playAgainPp').hide();
                scorePp=0;
                showPp();
            });
            $('#returnPp').click( function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });
        }
        var whereToAdd = document.getElementById("qaPp");
        // Check if already an unordered list is present. If so remove it.
        removeExistingQuestion(whereToAdd, "pp_choices");
    
        var qPp = document.createElement("h4");
        qPp.setAttribute('id', 'inquiry');
        var txt = document.createTextNode(pp[count].question);
        qPp.appendChild(txt);
        whereToAdd.appendChild(qPp);
        $('#scorePp').html(scorePp);
        $('#score2Pp').html(scorePp);
    
        // Firstly, create an unordered list of items
        var ulist = document.createElement("ul");
        ulist.setAttribute('id','pp_choices');
        // Create each choice
        for (var i = 0; i < pp[count].choices.length; ++i){
            // create a radio button for each choice
            var choice = document.createElement("input");
            choice.className = 'ch';
            choice.setAttribute('type','radio');
            choice.setAttribute('id','id'+i);
            choice.setAttribute('name','pp');
            choice.setAttribute('value',pp[count].choices[i]);
        
            //Add the choice to the UL element
            ulist.appendChild(choice);
        
            // Create a Label
            var ppLabel = document.createElement("label");
            ppLabel.htmlFor = choice.id;
            ppLabel.appendChild(choice);
            var ppNameTextNode = document.createTextNode(pp[count].choices[i]);
            ppLabel.appendChild(ppNameTextNode);
        
            // Add the UL item to the unordered list
            ulist.appendChild(ppLabel);

        }
        //At this point, the entire unordered list of items is created.
        //Add the unordered list to the div.
        whereToAdd.appendChild(ulist);
        $('#nextStopPp').show();
        $('#nextPp').click(function(){
            
            if ( $("input").is(':checked'))
            {
                var elements = document.getElementsByName('pp');
                for (var i = 0;i < elements.length; i++)
                    {
                        if (elements[i].checked)
                        {
                            if (elements[i].value == pp[count].correctChoice)
                            {
                                scorePp += 5;
                                break;
                            }
                         else
                            break;
                        }
                    }
                showPpQuestions();
            }
           
        });
        $('#stopPp').click(function(){
            $('#qaPp').hide();
            $('#nextStopPp').hide();
            $('#resultPp').show();
            $('#score2Pp').html(scorePp);
            $('#playAgainPp').show();
            $('#returnPp').show();
            $('#playAgainPp').click(function(){
                $('#returnPp').hide();
                $('#resultPp').hide();
                $('#playAgainPp').hide();
                scorePp=0;
                showPp();
            });
            $('#returnPp').click(function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });

        });
           
    });
}

function showShows() {
    for(var i=0; i<shows.length; i++)
        shows[i].flag = 0;
    $(document).ready(function showShowsQuestions(){
        $('#showsStartPage').hide();
        $('#qaShows').show();
        count = randomize(shows);
        if (count == -1)
        {
            $('#qaShows').hide();
            $('#nextStopShows').hide();
            $('#resultShows').show();
            $('#scoreShows').html(scoreShows);
            $('#playAgainShows').show();
            $('#returnShows').show();
            $('#playAgainShows').click(function(){
                $('#returnShows').hide();
                $('#resultShows').hide();
                $('#playAgainShows').hide();
                scoreShows=0;
                showShows();
            });
            $('#returnShows').click( function(){
               window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });

            });
        }
        var whereToAdd = document.getElementById("qaShows");
        // Check if already an unordered list is present. If so remove it.
        removeExistingQuestion(whereToAdd, "shows_choices");
    
        var qShows = document.createElement("h4");
        qShows.setAttribute('id', 'inquiry');
        var txt = document.createTextNode(shows[count].question);
        qShows.appendChild(txt);
        whereToAdd.appendChild(qShows);
        $('#scoreShows').html(scoreShows);
    
        // Firstly, create an unordered list of items
        var ulist = document.createElement("ul");
        ulist.setAttribute('id','shows_choices');
        // Create each choice
        for (var i = 0; i < shows[count].choices.length; ++i){
            // create a radio button for each choice
            var choice = document.createElement("input");
            choice.className = 'ch';
            choice.setAttribute('type','radio');
            choice.setAttribute('id','id'+i);
            choice.setAttribute('name','shows');
            choice.setAttribute('value',shows[count].choices[i]);
        
            //Add the choice to the UL element
            ulist.appendChild(choice);
        
            // Create a Label
            var showsLabel = document.createElement("label");
            showsLabel.htmlFor = choice.id;
            showsLabel.appendChild(choice);
            var showsNameTextNode = document.createTextNode(shows[count].choices[i]);
            showsLabel.appendChild(showsNameTextNode);
        
            // Add the UL item to the unordered list
            ulist.appendChild(showsLabel);

        }
        //At this point, the entire unordered list of items is created.
        //Add the unordered list to the div.
        whereToAdd.appendChild(ulist);
        $('#nextStopShows').show();
        $('#nextShows').click(function(){
            
            if ( $("input").is(':checked'))
            {
                var elements = document.getElementsByName('shows');
                for (var i = 0;i < elements.length; i++)
                    {
                        if (elements[i].checked)
                        {
                            if (elements[i].value == shows[count].correctChoice)
                            {
                                scoreShows += 5;
                                break;
                            }
                         else
                            break;
                        }
                    }
                showShowsQuestions();
            }
           
        });
        $('#stopShows').click(function(){
            $('#qaShows').hide();
            $('#nextStopShows').hide();
            $('#resultShows').show();
            $('#score2Shows').html(scoreShows);
            $('#playAgainShows').show();
            $('#returnShows').show();
            $('#playAgainShows').click(function(){
                $('#returnShows').hide();
                $('#resultShows').hide();
                $('#playAgainShows').hide();
                scoreShows=0;
                showShows();
            });
            $('#returnShows').click(function(){
               window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });

        });
           
    });
}

function showCartoons() {
    for(var i=0; i<cartoons.length; i++)
        cartoons[i].flag = 0;
    $(document).ready(function showCartoonsQuestions(){
        $('#cartoonsStartPage').hide();
        $('#qaCartoons').show();
        count = randomize(cartoons);
        if (count == -1)
        {
            $('#qaCartoons').hide();
            $('#nextStopCartoons').hide();
            $('#resultCartoons').show();
            $('#scoreCartoons').html(scoreCartoons);
            $('#playAgainCartoons').show();
            $('#returnCartoons').show();
            $('#playAgainCartoons').click(function(){
                $('#returnCartoons').hide();
                $('#resultCartoons').hide();
                $('#playAgainCartoons').hide();
                scoreCartoons=0;
                showCartoons();
            });
            $('#returnCartoons').click( function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });

            });
        }
        var whereToAdd = document.getElementById("qaCartoons");
        // Check if already an unordered list is present. If so remove it.
        removeExistingQuestion(whereToAdd, "cartoons_choices");
    
        var qCartoons = document.createElement("h4");
        qCartoons.setAttribute('id', 'inquiry');
        var txt = document.createTextNode(cartoons[count].question);
        qCartoons.appendChild(txt);
        whereToAdd.appendChild(qCartoons);
        $('#scoreCartoons').html(scoreCartoons);
    
        // Firstly, create an unordered list of items
        var ulist = document.createElement("ul");
        ulist.setAttribute('id','cartoons_choices');
        // Create each choice
        for (var i = 0; i < cartoons[count].choices.length; ++i){
            // create a radio button for each choice
            var choice = document.createElement("input");
            choice.className = 'ch';
            choice.setAttribute('type','radio');
            choice.setAttribute('id','id'+i);
            choice.setAttribute('name','cartoons');
            choice.setAttribute('value',cartoons[count].choices[i]);
        
            //Add the choice to the UL element
            ulist.appendChild(choice);
        
            // Create a Label
            var cartoonsLabel = document.createElement("label");
            cartoonsLabel.htmlFor = choice.id;
            cartoonsLabel.appendChild(choice);
            var cartoonsNameTextNode = document.createTextNode(cartoons[count].choices[i]);
            cartoonsLabel.appendChild(cartoonsNameTextNode);
        
            // Add the UL item to the unordered list
            ulist.appendChild(cartoonsLabel);

        }
        //At this point, the entire unordered list of items is created.
        //Add the unordered list to the div.
        whereToAdd.appendChild(ulist);
        $('#nextStopCartoons').show();
        $('#nextCartoons').click(function(){
            
            if ( $("input").is(':checked'))
            {
                var elements = document.getElementsByName('cartoons');
                for (var i = 0;i < elements.length; i++)
                    {
                        if (elements[i].checked)
                        {
                            if (elements[i].value == cartoons[count].correctChoice)
                            {
                                scoreCartoons += 5;
                                break;
                            }
                         else
                            break;
                        }
                    }
                showCartoonsQuestions();
            }
           
        });
        $('#stopCartoons').click(function(){
            $('#qaCartoons').hide();
            $('#nextStopCartoons').hide();
            $('#resultCartoons').show();
            $('#scoreCartoons').html(scoreShows);
            $('#playAgainCartoons').show();
            $('#returnCartoons').show();
            $('#playAgainCartoons').click(function(){
                $('#returnCartoons').hide();
                $('#resultCartoons').hide();
                $('#playAgainCartoons').hide();
                scoreCartoons=0;
                showCartoons();
            });
            $('#returnCartoons').click(function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });

        });
           
    });
}

function showFf() {
    for(var i=0; i<ff.length; i++)
        ff[i].flag = 0;
    $(document).ready(function showFfQuestions(){
        $('#ffStartPage').hide();
        $('#qaFf').show();
        count = randomize(ff);
        if (count == -1)
        {
            $('#qaFf').hide();
            $('#nextStopFf').hide();
            $('#resultFf').show();
            $('#scoreFf').html(scoreFf);
            $('#playAgainFf').show();
            $('#returnFf').show();
            $('#playAgainFf').click(function(){
                $('#returnFf').hide();
                $('#resultFf').hide();
                $('#playAgainFf').hide();
                scoreFf=0;
                showFf();
            });
            $('#returnFf').click( function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });
        }
        var whereToAdd = document.getElementById("qaFf");
        // Check if already an unordered list is present. If so remove it.
        removeExistingQuestion(whereToAdd, "ff_choices");
    
        var qFf = document.createElement("h4");
        qFf.setAttribute('id', 'inquiry');
        var txt = document.createTextNode(ff[count].question);
        qFf.appendChild(txt);
        whereToAdd.appendChild(qFf);
        $('#scoreFf').html(scoreFf);
        $('#score2Ff').html(scoreFf);
    
        // Firstly, create an unordered list of items
        var ulist = document.createElement("ul");
        ulist.setAttribute('id','ff_choices');
        // Create each choice
        for (var i = 0; i < ff[count].choices.length; ++i){
            // create a radio button for each choice
            var choice = document.createElement("input");
            choice.className = 'ch';
            choice.setAttribute('type','radio');
            choice.setAttribute('id','id'+i);
            choice.setAttribute('name','ff');
            choice.setAttribute('value',ff[count].choices[i]);
        
            //Add the choice to the UL element
            ulist.appendChild(choice);
        
            // Create a Label
            var ffLabel = document.createElement("label");
            ffLabel.htmlFor = choice.id;
            ffLabel.appendChild(choice);
            var ffNameTextNode = document.createTextNode(ff[count].choices[i]);
            ffLabel.appendChild(ffNameTextNode);
        
            // Add the UL item to the unordered list
            ulist.appendChild(ffLabel);

        }
        //At this point, the entire unordered list of items is created.
        //Add the unordered list to the div.
        whereToAdd.appendChild(ulist);
        $('#nextStopFf').show();
        $('#nextFf').click(function(){
            
            if ( $("input").is(':checked'))
            {
                var elements = document.getElementsByName('ff');
                for (var i = 0;i < elements.length; i++)
                    {
                        if (elements[i].checked)
                        {
                            if (elements[i].value == ff[count].correctChoice)
                            {
                                scoreFf += 5;
                                break;
                            }
                         else
                            break;
                        }
                    }
                showFfQuestions();
            }
           
        });
        $('#stopFf').click(function(){
            $('#qaFf').hide();
            $('#nextStopFf').hide();
            $('#resultFf').show();
            $('#score2Ff').html(scoreFf);
            $('#playAgainFf').show();
            $('#returnFf').show();
            $('#playAgainFf').click(function(){
                $('#returnFf').hide();
                $('#resultFf').hide();
                $('#playAgaiFf').hide();
                scoreFf=0;
                showFf();
            });
            $('#returnFf').click(function(){
                window.location.replace("#mainPage");
                $(document).on("pagebeforeshow","#mainPage", function() {
                    window.location.reload();
                });
            });

        });
           
    });
}



function removeExistingQuestion(parent, nameChoices){
    var elem = document.getElementById(nameChoices);
    var elem2 = document.getElementById("inquiry");
    if (elem != null)
        parent.removeChild(elem);
    if(elem2 != null)
        parent.removeChild(elem2);
}

function registerHandlers(){
	document.getElementById("startAa").onclick = showAa;
	document.getElementById("startWw").onclick = showWw;
	document.getElementById("startPp").onclick = showPp;
	document.getElementById("startShows").onclick = showShows;
	document.getElementById("startCartoons").onclick = showCartoons;
	document.getElementById("startFf").onclick = showFf;
    // document.getElementById("home").onclick = refresh;
    
}
// var total_seconds = 30*1;
// var c_seconds = parseInt(total_seconds%30);

// function CheckTime(){
// document.getElementById("quiz-time-left").innerHTML
// = 'Time Left: '+ c_seconds + ' seconds ' ;


// if(total_seconds <=0){
// setTimeout(1);
// } else {
// total_seconds = total_seconds -1;
// c_seconds = parseInt(total_seconds%60);
// setTimeout("CheckTime()",1000);
// }}
// setTimeout("CheckTime()",1000);
// $('#quit-btn-clear').on('click',function(){
//     exitFromApp();
// });
// function StartAaLoad()
//             {
//                   document.addEventListener("deviceready", onDeviceReady, false);
//             }

//  function exitFromApp()
//              {
//                 navigator.app.exitApp();
//              }